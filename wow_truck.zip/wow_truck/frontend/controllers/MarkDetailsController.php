<?php

namespace frontend\controllers;

use Yii;
use backend\models\MarkDetails;
use backend\models\Subject;
use backend\models\MarkDetailsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MarkDetailsController implements the CRUD actions for MarkDetails model.
 */
class MarkDetailsController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all MarkDetails models.
     * @return mixed
     */
    public function actionIndex()
    {
        $model = new MarkDetails();
        $result = $model->get_student_list();

        return $this->render('student_mark_list', [
            'result' => $result,
        ]);
    }

    /**
     * Displays a single MarkDetails model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new MarkDetails model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new MarkDetails();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing MarkDetails model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
         $model = new MarkDetails();
        $result = $model->get_student_list($id);
        if (Yii::$app->request->post()) {
			$post		=	Yii::$app->request->post();
			$mark		=	$post['mark'];
			$mark_id	=	$post['mark_id'];
			$subject_id	=	$post['subject_id'];
			if(count($mark))
			{
				for($i=0;$i<count($mark);$i++){
					if($mark_id[$i])
					{
						$model =	MarkDetails::findOne($mark_id[$i]);
						$model->mark 		=	$mark[$i];
						$model->update();
					}else{
						$model 				= 	new MarkDetails();
						$model->student_id 	=	$id;
						$model->subject_id 	=	$subject_id[$i];
						$model->mark 		=	$mark[$i];
						$model->save();
						//echo'<pre>';print_r($model->errors);exit;
					}
					
				}
			}
			
            return $this->redirect(['mark-details/index']);
        } else {
            return $this->render('update', [
                'model' => $model,
                'result' => $result,
                'subject' => Subject::find()->asArray()->all(),
            ]);
        }
    }

    /**
     * Deletes an existing MarkDetails model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the MarkDetails model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return MarkDetails the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = MarkDetails::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
