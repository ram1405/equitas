<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\MarkDetails */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="mark-details-form">
	<?php
		if(!empty($result))
		{
			$arr_mark		=	array();
			$arr_mark_id	=	array();
			foreach($result['markdetails'] as $val)
			{
				if($val['subject_id']==1)
				{
					$arr_mark[$val['subject_id']]		=	$val['mark'];
					$arr_mark_id[$val['subject_id']]	=	$val['id'];
				}else if($val['subject_id']==2)
				{
					$arr_mark[$val['subject_id']]		=	$val['mark'];
					$arr_mark_id[$val['subject_id']]	=	$val['id'];
				}else if($val['subject_id']==3)
				{
					$arr_mark[$val['subject_id']]		=	$val['mark'];
					$arr_mark_id[$val['subject_id']]	=	$val['id'];
				}
			}
		}
		
	?>
    <?php $form = ActiveForm::begin(); ?>

    <div class="form-group field-markdetails-mark required">
		<label for="markdetails-mark" class="control-label">Student Name</label>
		<label for="markdetails-mark" class="form-control"><?php echo $result['name']; ?></label>

		<div class="help-block"></div>
	</div>

		<?php
		
		foreach($subject as $sub_val)
		{
			$mark			=	isset($arr_mark[$sub_val['id']])?$arr_mark[$sub_val['id']]:0;
			$mark_id		=	isset($arr_mark_id[$sub_val['id']])?$arr_mark_id[$sub_val['id']]:0;
			?>
				<div class="form-group field-markdetails-mark required">
					<label for="markdetails-mark" class="control-label"><?php echo $sub_val['name'] ?></label>
					<input type="hidden" name="subject_id[]" class="form-control" id="subject_id" value="<?php echo $sub_val['id'] ?>">
					<input type="hidden" name="mark_id[]" class="form-control" id="markdetails-mark" value="<?php echo $mark_id ?>">
					<input type="number" min=0 max=100 name="mark[]" class="form-control" id="markdetails-mark" value="<?php echo $mark ?>">

					<div class="help-block"></div>
				</div>
			<?php
		}
	?>
    
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
